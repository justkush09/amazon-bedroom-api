from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

from sqlalchemy import select, func, or_, delete
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.logging import get_logger
from app.models.product import Product
from app.models.product_image import ProductImage
from app.models.product_feature import ProductFeature
from app.models.product_specification import ProductSpecification

logger = get_logger(__name__)


@dataclass
class ProductUpsertData:
    """Normalized representation of one product ready to persist."""

    asin: str
    title: str
    brand: str | None = None
    category_id: int | None = None
    subcategory_id: int | None = None
    product_url: str | None = None
    main_image: str | None = None
    current_price: float | None = None
    original_price: float | None = None
    discount: float | None = None
    currency: str | None = None
    rating: float | None = None
    reviews_count: int | None = None
    availability: str | None = None
    description: str | None = None
    images: list[str] = field(default_factory=list)
    features: list[str] = field(default_factory=list)
    specifications: dict[str, str] = field(default_factory=dict)


class ProductRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # ---------------------------------------------------------------- reads
    async def get_by_asin(self, asin: str) -> Product | None:
        stmt = (
            select(Product)
            .where(Product.asin == asin)
            .options(
                selectinload(Product.images),
                selectinload(Product.features),
                selectinload(Product.specifications),
            )
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_by_id(self, product_id: int) -> Product | None:
        stmt = (
            select(Product)
            .where(Product.id == product_id)
            .options(
                selectinload(Product.images),
                selectinload(Product.features),
                selectinload(Product.specifications),
                selectinload(Product.category),
                selectinload(Product.subcategory),
            )
        )
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_products(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        category_id: int | None = None,
        subcategory_id: int | None = None,
        brand: str | None = None,
        min_price: float | None = None,
        max_price: float | None = None,
        min_rating: float | None = None,
        in_stock: bool | None = None,
        sort_by: str = "date_imported",
        sort_dir: str = "desc",
    ) -> tuple[list[Product], int]:
        filters = []
        if category_id is not None:
            filters.append(Product.category_id == category_id)
        if subcategory_id is not None:
            filters.append(Product.subcategory_id == subcategory_id)
        if brand:
            filters.append(Product.brand.ilike(f"%{brand}%"))
        if min_price is not None:
            filters.append(Product.current_price >= min_price)
        if max_price is not None:
            filters.append(Product.current_price <= max_price)
        if min_rating is not None:
            filters.append(Product.rating >= min_rating)
        if in_stock is True:
            filters.append(Product.availability.ilike("%in stock%"))
        elif in_stock is False:
            filters.append(~Product.availability.ilike("%in stock%"))

        count_stmt = select(func.count(Product.id))
        if filters:
            count_stmt = count_stmt.where(*filters)
        total = (await self.session.execute(count_stmt)).scalar_one()

        sort_column = getattr(Product, sort_by, Product.date_imported)
        order = sort_column.desc() if sort_dir == "desc" else sort_column.asc()

        stmt = (
            select(Product)
            .options(
                selectinload(Product.category),
                selectinload(Product.subcategory),
            )
            .order_by(order)
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        if filters:
            stmt = stmt.where(*filters)

        result = await self.session.execute(stmt)
        return list(result.scalars().all()), total

    async def search(
        self, query: str, *, page: int = 1, page_size: int = 20
    ) -> tuple[list[Product], int]:
        like = f"%{query}%"
        conditions = or_(
            Product.title.ilike(like),
            Product.brand.ilike(like),
            Product.description.ilike(like),
            Product.asin.ilike(like),
        )

        total = (
            await self.session.execute(select(func.count(Product.id)).where(conditions))
        ).scalar_one()

        stmt = (
            select(Product)
            .options(selectinload(Product.category), selectinload(Product.subcategory))
            .where(conditions)
            .order_by(Product.date_imported.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all()), total

    # --------------------------------------------------------------- writes
    async def upsert(self, data: ProductUpsertData) -> tuple[Product, bool]:
        """
        Insert a new product or update an existing one, matched by ASIN.
        Child rows (images/features/specifications) are fully replaced.
        Returns (product, created).
        """
        existing = await self.get_by_asin(data.asin)
        created = existing is None

        if existing is None:
            product = Product(asin=data.asin)
            self.session.add(product)
        else:
            product = existing

        product.title = data.title
        product.brand = data.brand
        product.category_id = data.category_id
        product.subcategory_id = data.subcategory_id
        product.product_url = data.product_url
        product.main_image = data.main_image
        product.current_price = data.current_price
        product.original_price = data.original_price
        product.discount = data.discount
        product.currency = data.currency
        product.rating = data.rating
        product.reviews_count = data.reviews_count
        product.availability = data.availability
        product.description = data.description
        product.updated_at = dt.datetime.now(dt.timezone.utc)

        await self.session.flush()  # ensures product.id is available

        # Replace child collections
        await self.session.execute(delete(ProductImage).where(ProductImage.product_id == product.id))
        await self.session.execute(delete(ProductFeature).where(ProductFeature.product_id == product.id))
        await self.session.execute(
            delete(ProductSpecification).where(ProductSpecification.product_id == product.id)
        )

        for idx, url in enumerate(data.images):
            self.session.add(
                ProductImage(product_id=product.id, image_url=url, is_main=(idx == 0))
            )
        for text in data.features:
            self.session.add(ProductFeature(product_id=product.id, feature_text=text))
        for name, value in data.specifications.items():
            self.session.add(
                ProductSpecification(product_id=product.id, spec_name=name, spec_value=value)
            )

        await self.session.flush()
        return product, created

    # --------------------------------------------------------------- stats
    async def count_all(self) -> int:
        return (await self.session.execute(select(func.count(Product.id)))).scalar_one()

    async def average_price(self) -> float | None:
        result = await self.session.execute(select(func.avg(Product.current_price)))
        value = result.scalar_one()
        return float(value) if value is not None else None

    async def average_rating(self) -> float | None:
        result = await self.session.execute(select(func.avg(Product.rating)))
        value = result.scalar_one()
        return float(value) if value is not None else None

    async def count_in_stock(self) -> int:
        stmt = select(func.count(Product.id)).where(Product.availability.ilike("%in stock%"))
        return (await self.session.execute(stmt)).scalar_one()

    async def count_out_of_stock(self) -> int:
        stmt = select(func.count(Product.id)).where(
            ~Product.availability.ilike("%in stock%") | Product.availability.is_(None)
        )
        return (await self.session.execute(stmt)).scalar_one()

    async def last_import_at(self) -> dt.datetime | None:
        result = await self.session.execute(select(func.max(Product.date_imported)))
        return result.scalar_one()

    async def top_brands(self, limit: int = 10) -> list[tuple[str, int]]:
        stmt = (
            select(Product.brand, func.count(Product.id))
            .where(Product.brand.is_not(None))
            .group_by(Product.brand)
            .order_by(func.count(Product.id).desc())
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return [(row[0], row[1]) for row in result.all()]
