from __future__ import annotations

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.subcategory import Subcategory
from app.models.product import Product


class SubcategoryRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_name(self, category_id: int, name: str) -> Subcategory | None:
        result = await self.session.execute(
            select(Subcategory).where(
                Subcategory.category_id == category_id, Subcategory.name == name
            )
        )
        return result.scalar_one_or_none()

    async def get_or_create(self, category_id: int, name: str) -> Subcategory:
        subcategory = await self.get_by_name(category_id, name)
        if subcategory:
            return subcategory
        subcategory = Subcategory(category_id=category_id, name=name)
        self.session.add(subcategory)
        await self.session.flush()
        return subcategory

    async def list_all(self, category_id: int | None = None) -> list[Subcategory]:
        stmt = select(Subcategory).order_by(Subcategory.name)
        if category_id is not None:
            stmt = stmt.where(Subcategory.category_id == category_id)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def list_with_counts(self, category_id: int | None = None) -> list[tuple[Subcategory, int]]:
        stmt = (
            select(Subcategory, func.count(Product.id))
            .outerjoin(Product, Product.subcategory_id == Subcategory.id)
            .group_by(Subcategory.id)
            .order_by(Subcategory.name)
        )
        if category_id is not None:
            stmt = stmt.where(Subcategory.category_id == category_id)
        result = await self.session.execute(stmt)
        return [(row[0], row[1]) for row in result.all()]
