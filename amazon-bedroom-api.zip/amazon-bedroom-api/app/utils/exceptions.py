"""
Custom exception types used across services and repositories.
"""


class PAAPIError(Exception):
    """Raised when the Amazon Product Advertising API returns an error."""


class PAAPIRateLimitError(PAAPIError):
    """Raised specifically on HTTP 429 responses from PA-API, to trigger retry/backoff."""


class ImportError_(Exception):
    """Raised when the import pipeline cannot complete a unit of work."""


class ProductNotFoundError(Exception):
    """Raised when a requested product ID/ASIN does not exist."""
