from __future__ import annotations

import datetime as dt

from sqlalchemy import (
    String,
    Text,
    Numeric,
    Integer,
    DateTime,
    ForeignKey,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True)

    asin: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    title: Mapped[str] = mapped_column(Text, nullable=False)
    brand: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)

    category_id: Mapped[int | None] = mapped_column(
        ForeignKey("categories.id", ondelete="SET NULL"), nullable=True, index=True
    )
    subcategory_id: Mapped[int | None] = mapped_column(
        ForeignKey("subcategories.id", ondelete="SET NULL"), nullable=True, index=True
    )

    product_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    main_image: Mapped[str | None] = mapped_column(Text, nullable=True)

    current_price: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)
    original_price: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)
    discount: Mapped[float | None] = mapped_column(Numeric(5, 2), nullable=True)
    currency: Mapped[str | None] = mapped_column(String(10), nullable=True)

    rating: Mapped[float | None] = mapped_column(Numeric(3, 2), nullable=True)
    reviews_count: Mapped[int | None] = mapped_column(Integer, nullable=True)

    availability: Mapped[str | None] = mapped_column(String(255), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    date_imported: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[dt.datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    category: Mapped["Category"] = relationship(back_populates="products")
    subcategory: Mapped["Subcategory"] = relationship(back_populates="products")

    images: Mapped[list["ProductImage"]] = relationship(
        back_populates="product", cascade="all, delete-orphan", order_by="ProductImage.id"
    )
    features: Mapped[list["ProductFeature"]] = relationship(
        back_populates="product", cascade="all, delete-orphan", order_by="ProductFeature.id"
    )
    specifications: Mapped[list["ProductSpecification"]] = relationship(
        back_populates="product", cascade="all, delete-orphan", order_by="ProductSpecification.id"
    )

    def __repr__(self) -> str:
        return f"<Product id={self.id} asin={self.asin!r} title={self.title[:30]!r}>"
