"""
Import all models here so Alembic's autogenerate and Base.metadata
can discover every mapped class from a single entry point.
"""
from app.models.category import Category
from app.models.subcategory import Subcategory
from app.models.product import Product
from app.models.product_image import ProductImage
from app.models.product_feature import ProductFeature
from app.models.product_specification import ProductSpecification

__all__ = [
    "Category",
    "Subcategory",
    "Product",
    "ProductImage",
    "ProductFeature",
    "ProductSpecification",
]
