from __future__ import annotations

import datetime as dt
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field


class ProductImageRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    image_url: str
    is_main: bool


class ProductFeatureRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    feature_text: str


class ProductSpecificationRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    spec_name: str
    spec_value: str


class ProductBase(BaseModel):
    asin: str
    title: str
    brand: str | None = None
    product_url: str | None = None
    main_image: str | None = None
    current_price: Decimal | None = None
    original_price: Decimal | None = None
    discount: Decimal | None = None
    currency: str | None = None
    rating: Decimal | None = None
    reviews_count: int | None = None
    availability: str | None = None
    description: str | None = None


class ProductListItem(ProductBase):
    """Lightweight representation used in list/search endpoints."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    category: str | None = Field(default=None, validate_default=False)
    subcategory: str | None = Field(default=None, validate_default=False)
    date_imported: dt.datetime


class ProductDetail(ProductBase):
    """Full representation with all nested collections."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    category: str | None = None
    subcategory: str | None = None
    date_imported: dt.datetime
    updated_at: dt.datetime
    images: list[ProductImageRead] = []
    features: list[ProductFeatureRead] = []
    specifications: list[ProductSpecificationRead] = []


class PaginatedProducts(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    items: list[ProductListItem]
