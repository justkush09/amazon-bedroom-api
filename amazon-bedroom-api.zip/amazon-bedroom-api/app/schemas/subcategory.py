from __future__ import annotations

import datetime as dt

from pydantic import BaseModel, ConfigDict


class SubcategoryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    category_id: int
    name: str
    created_at: dt.datetime


class SubcategoryWithCount(SubcategoryRead):
    product_count: int = 0
