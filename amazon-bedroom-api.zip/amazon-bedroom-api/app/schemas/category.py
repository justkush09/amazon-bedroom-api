from __future__ import annotations

import datetime as dt

from pydantic import BaseModel, ConfigDict


class CategoryRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    created_at: dt.datetime


class CategoryWithCount(CategoryRead):
    product_count: int = 0
