from __future__ import annotations

from pydantic import BaseModel


class CategoryBreakdown(BaseModel):
    category: str
    product_count: int


class BrandBreakdown(BaseModel):
    brand: str
    product_count: int


class StatsResponse(BaseModel):
    total_products: int
    total_categories: int
    total_subcategories: int
    average_price: float | None
    average_rating: float | None
    in_stock_count: int
    out_of_stock_count: int
    products_by_category: list[CategoryBreakdown]
    top_brands: list[BrandBreakdown]
    last_import_at: str | None
