from __future__ import annotations

from pydantic import BaseModel, Field


class ImportRequest(BaseModel):
    """
    Optional filters for the import job. If `categories` is omitted,
    every bedroom category is imported.
    """
    categories: list[str] | None = Field(
        default=None,
        description="Subset of bedroom categories to import, e.g. ['Beds', 'Mattresses']. "
        "Omit to import all categories.",
    )
    items_per_subcategory: int | None = Field(
        default=None,
        ge=1,
        le=10,
        description="Max items fetched per subcategory search (PA-API max is 10 per page).",
    )


class CategoryImportResult(BaseModel):
    category: str
    subcategory: str
    fetched: int
    inserted: int
    updated: int
    failed: int
    errors: list[str] = []


class ImportSummary(BaseModel):
    started_at: str
    finished_at: str
    total_fetched: int
    total_inserted: int
    total_updated: int
    total_failed: int
    results: list[CategoryImportResult]
