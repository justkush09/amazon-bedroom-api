"""
Shared FastAPI dependencies.
"""
from app.core.config import Settings, get_settings
from app.core.database import get_db

__all__ = ["get_settings", "Settings", "get_db"]
