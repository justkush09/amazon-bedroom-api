from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check(session: AsyncSession = Depends(get_db)) -> dict:
    db_ok = True
    error: str | None = None
    try:
        await session.execute(text("SELECT 1"))
    except Exception as exc:  # pragma: no cover - defensive
        db_ok = False
        error = str(exc)

    return {
        "status": "ok" if db_ok else "degraded",
        "database": "up" if db_ok else "down",
        "error": error,
        "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
    }
