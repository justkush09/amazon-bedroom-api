from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.repositories.category_repo import CategoryRepository
from app.schemas.category import CategoryWithCount

router = APIRouter(tags=["categories"])


@router.get("/categories", response_model=list[CategoryWithCount])
async def list_categories(session: AsyncSession = Depends(get_db)) -> list[CategoryWithCount]:
    repo = CategoryRepository(session)
    rows = await repo.list_with_counts()
    return [
        CategoryWithCount(
            id=category.id,
            name=category.name,
            created_at=category.created_at,
            product_count=count,
        )
        for category, count in rows
    ]
