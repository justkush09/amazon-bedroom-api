from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.repositories.subcategory_repo import SubcategoryRepository
from app.schemas.subcategory import SubcategoryWithCount

router = APIRouter(tags=["subcategories"])


@router.get("/subcategories", response_model=list[SubcategoryWithCount])
async def list_subcategories(
    category_id: int | None = Query(default=None, description="Filter by parent category id"),
    session: AsyncSession = Depends(get_db),
) -> list[SubcategoryWithCount]:
    repo = SubcategoryRepository(session)
    rows = await repo.list_with_counts(category_id=category_id)
    return [
        SubcategoryWithCount(
            id=subcategory.id,
            category_id=subcategory.category_id,
            name=subcategory.name,
            created_at=subcategory.created_at,
            product_count=count,
        )
        for subcategory, count in rows
    ]
