from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_settings
from app.core.config import Settings
from app.core.logging import get_logger
from app.schemas.import_ import ImportRequest, ImportSummary
from app.services.import_service import ImportService

router = APIRouter(tags=["import"])
logger = get_logger(__name__)


@router.post("/import", response_model=ImportSummary)
async def import_products(
    request: ImportRequest | None = None,
    session: AsyncSession = Depends(get_db),
    settings: Settings = Depends(get_settings),
) -> ImportSummary:
    """
    Fetch bedroom products from the Amazon Product Advertising API and
    upsert them into PostgreSQL, matched and de-duplicated by ASIN.

    This runs synchronously and returns a full summary once the import
    completes (categories x subcategories x items is intentionally kept
    small per PA-API's ~1 request/second default rate limit).
    """
    request = request or ImportRequest()
    logger.info("Import requested: categories=%s", request.categories or "ALL")

    service = ImportService(session, settings)
    summary = await service.run_import(
        categories=request.categories,
        items_per_subcategory=request.items_per_subcategory,
    )
    return summary
