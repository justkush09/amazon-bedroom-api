from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.repositories.category_repo import CategoryRepository
from app.repositories.product_repo import ProductRepository
from app.repositories.subcategory_repo import SubcategoryRepository
from app.schemas.stats import BrandBreakdown, CategoryBreakdown, StatsResponse

router = APIRouter(tags=["stats"])


@router.get("/stats", response_model=StatsResponse)
async def get_stats(session: AsyncSession = Depends(get_db)) -> StatsResponse:
    product_repo = ProductRepository(session)
    category_repo = CategoryRepository(session)
    subcategory_repo = SubcategoryRepository(session)

    total_products = await product_repo.count_all()
    category_rows = await category_repo.list_with_counts()
    subcategories = await subcategory_repo.list_all()
    avg_price = await product_repo.average_price()
    avg_rating = await product_repo.average_rating()
    in_stock = await product_repo.count_in_stock()
    out_of_stock = await product_repo.count_out_of_stock()
    last_import = await product_repo.last_import_at()
    top_brands = await product_repo.top_brands(limit=10)

    return StatsResponse(
        total_products=total_products,
        total_categories=len(category_rows),
        total_subcategories=len(subcategories),
        average_price=round(avg_price, 2) if avg_price is not None else None,
        average_rating=round(avg_rating, 2) if avg_rating is not None else None,
        in_stock_count=in_stock,
        out_of_stock_count=out_of_stock,
        products_by_category=[
            CategoryBreakdown(category=category.name, product_count=count)
            for category, count in category_rows
        ],
        top_brands=[BrandBreakdown(brand=brand, product_count=count) for brand, count in top_brands],
        last_import_at=last_import.isoformat() if last_import else None,
    )
