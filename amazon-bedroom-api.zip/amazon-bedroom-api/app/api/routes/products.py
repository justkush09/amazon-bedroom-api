from __future__ import annotations

import math

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.api.routes._mappers import to_detail, to_list_item
from app.repositories.product_repo import ProductRepository
from app.schemas.product import PaginatedProducts, ProductDetail

router = APIRouter(tags=["products"])

ALLOWED_SORT_FIELDS = {"date_imported", "current_price", "rating", "reviews_count", "title"}


@router.get("/products", response_model=PaginatedProducts)
async def list_products(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    category_id: int | None = None,
    subcategory_id: int | None = None,
    brand: str | None = None,
    min_price: float | None = Query(default=None, ge=0),
    max_price: float | None = Query(default=None, ge=0),
    min_rating: float | None = Query(default=None, ge=0, le=5),
    in_stock: bool | None = None,
    sort_by: str = Query(default="date_imported"),
    sort_dir: str = Query(default="desc", pattern="^(asc|desc)$"),
    session: AsyncSession = Depends(get_db),
) -> PaginatedProducts:
    if sort_by not in ALLOWED_SORT_FIELDS:
        raise HTTPException(status_code=400, detail=f"sort_by must be one of {sorted(ALLOWED_SORT_FIELDS)}")

    repo = ProductRepository(session)
    products, total = await repo.list_products(
        page=page,
        page_size=page_size,
        category_id=category_id,
        subcategory_id=subcategory_id,
        brand=brand,
        min_price=min_price,
        max_price=max_price,
        min_rating=min_rating,
        in_stock=in_stock,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )

    total_pages = math.ceil(total / page_size) if total else 0
    return PaginatedProducts(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        items=[to_list_item(p) for p in products],
    )


@router.get("/products/{product_id}", response_model=ProductDetail)
async def get_product(product_id: int, session: AsyncSession = Depends(get_db)) -> ProductDetail:
    repo = ProductRepository(session)
    product = await repo.get_by_id(product_id)
    if product is None:
        raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
    return to_detail(product)
