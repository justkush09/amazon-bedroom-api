"""
Helpers to convert ORM Product instances into API response schemas.
Kept in one place so /products and /search stay consistent.
"""
from __future__ import annotations

from app.models.product import Product
from app.schemas.product import ProductDetail, ProductListItem


def to_list_item(product: Product) -> ProductListItem:
    return ProductListItem(
        id=product.id,
        asin=product.asin,
        title=product.title,
        brand=product.brand,
        category=product.category.name if product.category else None,
        subcategory=product.subcategory.name if product.subcategory else None,
        product_url=product.product_url,
        main_image=product.main_image,
        current_price=product.current_price,
        original_price=product.original_price,
        discount=product.discount,
        currency=product.currency,
        rating=product.rating,
        reviews_count=product.reviews_count,
        availability=product.availability,
        description=product.description,
        date_imported=product.date_imported,
    )


def to_detail(product: Product) -> ProductDetail:
    return ProductDetail(
        id=product.id,
        asin=product.asin,
        title=product.title,
        brand=product.brand,
        category=product.category.name if product.category else None,
        subcategory=product.subcategory.name if product.subcategory else None,
        product_url=product.product_url,
        main_image=product.main_image,
        current_price=product.current_price,
        original_price=product.original_price,
        discount=product.discount,
        currency=product.currency,
        rating=product.rating,
        reviews_count=product.reviews_count,
        availability=product.availability,
        description=product.description,
        date_imported=product.date_imported,
        updated_at=product.updated_at,
        images=list(product.images),
        features=list(product.features),
        specifications=list(product.specifications),
    )
