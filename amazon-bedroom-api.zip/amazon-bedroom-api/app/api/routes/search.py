from __future__ import annotations

import math

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db
from app.api.routes._mappers import to_list_item
from app.repositories.product_repo import ProductRepository
from app.schemas.product import PaginatedProducts

router = APIRouter(tags=["search"])


@router.get("/search", response_model=PaginatedProducts)
async def search_products(
    q: str = Query(..., min_length=1, description="Free-text search across title, brand, description, ASIN"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    session: AsyncSession = Depends(get_db),
) -> PaginatedProducts:
    repo = ProductRepository(session)
    products, total = await repo.search(q, page=page, page_size=page_size)
    total_pages = math.ceil(total / page_size) if total else 0
    return PaginatedProducts(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        items=[to_list_item(p) for p in products],
    )
