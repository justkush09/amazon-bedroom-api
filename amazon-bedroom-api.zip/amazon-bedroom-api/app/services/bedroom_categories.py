"""
Static taxonomy describing the bedroom product categories this system
imports, and the search keywords used against PA-API's SearchItems
operation for each subcategory.
"""
from __future__ import annotations

BEDROOM_TAXONOMY: dict[str, list[str]] = {
    "Beds": ["Single Bed Frame", "King Size Bed Frame", "Bunk Bed"],
    "Wardrobes": ["Sliding Door Wardrobe", "Hinged Door Wardrobe"],
    "Bedside Tables": ["Wooden Bedside Table", "Modern Nightstand"],
    "Mattresses": ["Memory Foam Mattress", "Spring Mattress", "Orthopedic Mattress"],
    "Dressing Tables": ["Dressing Table with Mirror", "Compact Dressing Table"],
    "Bedroom Furniture Sets": ["Wooden Bedroom Furniture Set", "Modern Bedroom Set"],
    "Lighting": ["Bedside Lamp", "Bedroom Ceiling Light", "LED String Lights Bedroom"],
    "Rugs": ["Bedroom Area Rug", "Fluffy Bedroom Rug"],
    "Curtains": ["Blackout Curtains Bedroom", "Sheer Curtains"],
    "Bedsheets": ["Cotton Bedsheet Set", "Silk Bedsheet Set"],
    "Pillows": ["Memory Foam Pillow", "Cooling Pillow"],
    "Blankets": ["Fleece Blanket", "Weighted Blanket"],
    "Wall Decor": ["Bedroom Wall Art", "Wall Hanging Decor"],
    "Mirrors": ["Wall Mirror Bedroom", "Full Length Mirror"],
    "Storage Cabinets": ["Bedroom Storage Cabinet", "Under Bed Storage Box"],
}


def get_categories(subset: list[str] | None = None) -> dict[str, list[str]]:
    """Return the taxonomy, optionally filtered to a subset of category names."""
    if not subset:
        return BEDROOM_TAXONOMY
    normalized = {name.strip().lower() for name in subset}
    return {
        name: subcats
        for name, subcats in BEDROOM_TAXONOMY.items()
        if name.lower() in normalized
    }
