"""
Official Amazon Product Advertising API (PA-API) 5.0 client.

Implements AWS Signature Version 4 request signing and calls the
SearchItems / GetItems operations over HTTPS + JSON, exactly as
documented at https://webservices.amazon.com/paapi5/documentation/.

No third-party PA-API SDK is used; requests are signed and sent
directly with httpx so behavior is fully transparent and auditable.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.core.config import Settings
from app.core.logging import get_logger
from app.utils.exceptions import PAAPIError, PAAPIRateLimitError

logger = get_logger(__name__)

SERVICE = "ProductAdvertisingAPI"
SEARCH_ITEMS_TARGET = "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems"
GET_ITEMS_TARGET = "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems"

RESOURCES = [
    "ItemInfo.Title",
    "ItemInfo.ByLineInfo",
    "ItemInfo.Features",
    "ItemInfo.ProductInfo",
    "ItemInfo.ContentInfo",
    "ItemInfo.TechnicalInfo",
    "ItemInfo.Classifications",
    "Images.Primary.Large",
    "Images.Variants.Large",
    "Offers.Listings.Price",
    "Offers.Listings.SavingBasis",
    "Offers.Listings.Availability.Message",
    "CustomerReviews.Count",
    "CustomerReviews.StarRating",
    "ParentASIN",
]


def _sign(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _signing_key(secret_key: str, date_stamp: str, region: str, service: str) -> bytes:
    k_date = _sign(f"AWS4{secret_key}".encode("utf-8"), date_stamp)
    k_region = _sign(k_date, region)
    k_service = _sign(k_region, service)
    return _sign(k_service, "aws4_request")


class PAAPIClient:
    """Thin async client for Amazon's Product Advertising API 5.0."""

    def __init__(self, settings: Settings) -> None:
        self.access_key = settings.PAAPI_ACCESS_KEY
        self.secret_key = settings.PAAPI_SECRET_KEY
        self.partner_tag = settings.PAAPI_PARTNER_TAG
        self.partner_type = settings.PAAPI_PARTNER_TYPE
        self.host = settings.PAAPI_HOST
        self.region = settings.PAAPI_REGION
        self.marketplace = settings.PAAPI_MARKETPLACE

    def _build_headers_and_sign(self, path: str, target: str, payload: dict) -> tuple[dict, str]:
        body = json.dumps(payload, separators=(",", ":"))
        now = dt.datetime.now(dt.timezone.utc)
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")

        canonical_headers = (
            f"content-encoding:amz-1.0\n"
            f"content-type:application/json; charset=utf-8\n"
            f"host:{self.host}\n"
            f"x-amz-date:{amz_date}\n"
            f"x-amz-target:{target}\n"
        )
        signed_headers = "content-encoding;content-type;host;x-amz-date;x-amz-target"
        payload_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()

        canonical_request = (
            f"POST\n{path}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
        )

        credential_scope = f"{date_stamp}/{self.region}/{SERVICE}/aws4_request"
        string_to_sign = (
            f"AWS4-HMAC-SHA256\n{amz_date}\n{credential_scope}\n"
            f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
        )

        signing_key = _signing_key(self.secret_key, date_stamp, self.region, SERVICE)
        signature = hmac.new(
            signing_key, string_to_sign.encode("utf-8"), hashlib.sha256
        ).hexdigest()

        authorization = (
            f"AWS4-HMAC-SHA256 Credential={self.access_key}/{credential_scope}, "
            f"SignedHeaders={signed_headers}, Signature={signature}"
        )

        headers = {
            "content-encoding": "amz-1.0",
            "content-type": "application/json; charset=utf-8",
            "host": self.host,
            "x-amz-date": amz_date,
            "x-amz-target": target,
            "Authorization": authorization,
        }
        return headers, body

    @retry(
        reraise=True,
        stop=stop_after_attempt(4),
        wait=wait_exponential(multiplier=1.5, min=1, max=20),
        retry=retry_if_exception_type(PAAPIRateLimitError),
    )
    async def _post(self, path: str, target: str, payload: dict) -> dict:
        headers, body = self._build_headers_and_sign(path, target, payload)
        url = f"https://{self.host}{path}"

        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.post(url, headers=headers, content=body)

        if response.status_code == 429:
            logger.warning("PA-API rate limit hit; will retry with backoff")
            raise PAAPIRateLimitError("Rate limited by PA-API (HTTP 429)")

        if response.status_code >= 400:
            logger.error("PA-API error %s: %s", response.status_code, response.text[:500])
            raise PAAPIError(f"PA-API request failed with HTTP {response.status_code}: {response.text[:300]}")

        return response.json()

    async def search_items(self, keywords: str, item_count: int = 10, item_page: int = 1) -> dict:
        payload = {
            "Keywords": keywords,
            "SearchIndex": "All",
            "ItemCount": min(max(item_count, 1), 10),
            "ItemPage": item_page,
            "PartnerTag": self.partner_tag,
            "PartnerType": self.partner_type,
            "Marketplace": self.marketplace,
            "Resources": RESOURCES,
        }
        return await self._post("/paapi5/searchitems", SEARCH_ITEMS_TARGET, payload)

    async def get_items(self, asins: list[str]) -> dict:
        payload = {
            "ItemIds": asins[:10],  # PA-API allows up to 10 per request
            "PartnerTag": self.partner_tag,
            "PartnerType": self.partner_type,
            "Marketplace": self.marketplace,
            "Resources": RESOURCES,
        }
        return await self._post("/paapi5/getitems", GET_ITEMS_TARGET, payload)


def parse_paapi_item(raw_item: dict) -> dict:
    """
    Flatten a single PA-API 'Items[]' entry into the plain dict shape
    consumed by ProductUpsertData.
    """
    asin = raw_item.get("ASIN", "")

    item_info = raw_item.get("ItemInfo", {}) or {}
    title = (item_info.get("Title", {}) or {}).get("DisplayValue", "") or "Unknown product"
    brand = (item_info.get("ByLineInfo", {}) or {}).get("Brand", {}).get("DisplayValue")

    features_block = (item_info.get("Features", {}) or {}).get("DisplayValues", []) or []

    detail_url = raw_item.get("DetailPageURL")

    images_block = raw_item.get("Images", {}) or {}
    primary = ((images_block.get("Primary", {}) or {}).get("Large", {}) or {}).get("URL")
    variants = images_block.get("Variants", []) or []
    all_images = []
    if primary:
        all_images.append(primary)
    for variant in variants:
        url = (variant.get("Large", {}) or {}).get("URL")
        if url and url not in all_images:
            all_images.append(url)

    offers = raw_item.get("Offers", {}) or {}
    listings = offers.get("Listings", []) or []
    current_price = None
    currency = None
    original_price = None
    availability = None
    if listings:
        listing = listings[0]
        price_block = listing.get("Price", {}) or {}
        current_price = price_block.get("Amount")
        currency = price_block.get("Currency")
        saving_basis = listing.get("SavingBasis", {}) or {}
        original_price = saving_basis.get("Amount")
        availability = (listing.get("Availability", {}) or {}).get("Message")

    discount = None
    if current_price is not None and original_price and original_price > 0:
        discount = round((1 - (current_price / original_price)) * 100, 2)

    reviews_block = raw_item.get("CustomerReviews", {}) or {}
    rating = reviews_block.get("StarRating", {}).get("Value") if reviews_block.get("StarRating") else None
    reviews_count = reviews_block.get("Count")

    product_info = item_info.get("ProductInfo", {}) or {}
    technical_info = item_info.get("TechnicalInfo", {}) or {}
    specifications: dict[str, str] = {}
    for key, block in {**product_info, **technical_info}.items():
        if isinstance(block, dict) and "DisplayValue" in block:
            specifications[key] = str(block["DisplayValue"])

    description = None
    content_info = item_info.get("ContentInfo", {}) or {}
    if content_info:
        description = "; ".join(
            str(v.get("DisplayValue")) for v in content_info.values()
            if isinstance(v, dict) and v.get("DisplayValue")
        ) or None
    if not description and features_block:
        description = " ".join(features_block[:3])

    return {
        "asin": asin,
        "title": title,
        "brand": brand,
        "product_url": detail_url,
        "main_image": primary,
        "images": all_images,
        "current_price": current_price,
        "original_price": original_price,
        "discount": discount,
        "currency": currency,
        "rating": rating,
        "reviews_count": reviews_count,
        "availability": availability,
        "description": description,
        "features": features_block,
        "specifications": specifications,
    }
