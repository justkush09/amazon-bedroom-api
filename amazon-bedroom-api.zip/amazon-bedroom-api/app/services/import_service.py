"""
Import orchestration: walks the bedroom taxonomy, calls PA-API for each
subcategory, parses results, and upserts them into PostgreSQL in
batches (one commit per subcategory) with full error isolation so a
single bad item or a single failed subcategory never aborts the run.
"""
from __future__ import annotations

import asyncio
import datetime as dt

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.core.logging import get_logger
from app.models.category import Category
from app.repositories.category_repo import CategoryRepository
from app.repositories.subcategory_repo import SubcategoryRepository
from app.repositories.product_repo import ProductRepository, ProductUpsertData
from app.schemas.import_ import CategoryImportResult, ImportSummary
from app.services.bedroom_categories import get_categories
from app.services.paapi_client import PAAPIClient, parse_paapi_item
from app.utils.exceptions import PAAPIError

logger = get_logger(__name__)


class ImportService:
    def __init__(self, session: AsyncSession, settings: Settings) -> None:
        self.session = session
        self.settings = settings
        self.client = PAAPIClient(settings)
        self.category_repo = CategoryRepository(session)
        self.subcategory_repo = SubcategoryRepository(session)
        self.product_repo = ProductRepository(session)

    async def run_import(
        self,
        categories: list[str] | None = None,
        items_per_subcategory: int | None = None,
    ) -> ImportSummary:
        taxonomy = get_categories(categories)
        item_count = items_per_subcategory or self.settings.ITEMS_PER_SUBCATEGORY

        started_at = dt.datetime.now(dt.timezone.utc)
        results: list[CategoryImportResult] = []
        totals = {"fetched": 0, "inserted": 0, "updated": 0, "failed": 0}

        logger.info(
            "Starting import: %d categories, %d items/subcategory",
            len(taxonomy), item_count,
        )

        for category_name, subcategory_names in taxonomy.items():
            category = await self.category_repo.get_or_create(category_name)
            await self.session.commit()

            for subcategory_name in subcategory_names:
                result = await self._import_subcategory(category, subcategory_name, item_count)
                results.append(result)
                totals["fetched"] += result.fetched
                totals["inserted"] += result.inserted
                totals["updated"] += result.updated
                totals["failed"] += result.failed

                # Respect PA-API's rate limit between calls.
                await asyncio.sleep(self.settings.PAAPI_REQUEST_DELAY_SECONDS)

        finished_at = dt.datetime.now(dt.timezone.utc)
        logger.info(
            "Import finished: fetched=%d inserted=%d updated=%d failed=%d",
            totals["fetched"], totals["inserted"], totals["updated"], totals["failed"],
        )

        return ImportSummary(
            started_at=started_at.isoformat(),
            finished_at=finished_at.isoformat(),
            total_fetched=totals["fetched"],
            total_inserted=totals["inserted"],
            total_updated=totals["updated"],
            total_failed=totals["failed"],
            results=results,
        )

    async def _import_subcategory(
        self, category: Category, subcategory_name: str, item_count: int
    ) -> CategoryImportResult:
        errors: list[str] = []
        fetched = inserted = updated = failed = 0

        try:
            subcategory = await self.subcategory_repo.get_or_create(category.id, subcategory_name)
            await self.session.commit()
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("Could not create subcategory %s", subcategory_name)
            return CategoryImportResult(
                category=category.name, subcategory=subcategory_name,
                fetched=0, inserted=0, updated=0, failed=1, errors=[str(exc)],
            )

        try:
            response = await self.client.search_items(subcategory_name, item_count=item_count)
        except PAAPIError as exc:
            logger.error("PA-API search failed for %s / %s: %s", category.name, subcategory_name, exc)
            return CategoryImportResult(
                category=category.name, subcategory=subcategory_name,
                fetched=0, inserted=0, updated=0, failed=1, errors=[str(exc)],
            )

        api_errors = (response or {}).get("Errors") or []
        for err in api_errors:
            errors.append(err.get("Message", str(err)))

        items = ((response or {}).get("SearchResult") or {}).get("Items") or []
        fetched = len(items)

        for raw_item in items:
            try:
                parsed = parse_paapi_item(raw_item)
                if not parsed.get("asin"):
                    failed += 1
                    errors.append("Skipped item with missing ASIN")
                    continue

                data = ProductUpsertData(
                    asin=parsed["asin"],
                    title=parsed["title"],
                    brand=parsed["brand"],
                    category_id=category.id,
                    subcategory_id=subcategory.id,
                    product_url=parsed["product_url"],
                    main_image=parsed["main_image"],
                    current_price=parsed["current_price"],
                    original_price=parsed["original_price"],
                    discount=parsed["discount"],
                    currency=parsed["currency"],
                    rating=parsed["rating"],
                    reviews_count=parsed["reviews_count"],
                    availability=parsed["availability"],
                    description=parsed["description"],
                    images=parsed["images"],
                    features=parsed["features"],
                    specifications=parsed["specifications"],
                )
                _, created = await self.product_repo.upsert(data)
                if created:
                    inserted += 1
                else:
                    updated += 1
            except Exception as exc:  # pragma: no cover - defensive, isolate per-item failures
                failed += 1
                asin = raw_item.get("ASIN", "unknown")
                logger.exception("Failed to import item %s", asin)
                errors.append(f"{asin}: {exc}")

        try:
            await self.session.commit()  # single batched commit per subcategory
        except Exception as exc:
            await self.session.rollback()
            logger.exception("Commit failed for %s / %s", category.name, subcategory_name)
            return CategoryImportResult(
                category=category.name, subcategory=subcategory_name,
                fetched=fetched, inserted=0, updated=0, failed=fetched, errors=[str(exc)],
            )

        return CategoryImportResult(
            category=category.name,
            subcategory=subcategory_name,
            fetched=fetched,
            inserted=inserted,
            updated=updated,
            failed=failed,
            errors=errors,
        )
