"""
Application configuration, loaded from environment variables / .env file.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "Bedroom Products API"
    APP_ENV: str = "development"
    LOG_LEVEL: str = "INFO"

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://bedroom_user:change_me@localhost:5432/bedroom_products"
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_ECHO: bool = False

    # Amazon PA-API 5.0
    PAAPI_ACCESS_KEY: str = ""
    PAAPI_SECRET_KEY: str = ""
    PAAPI_PARTNER_TAG: str = ""
    PAAPI_PARTNER_TYPE: str = "Associates"
    PAAPI_HOST: str = "webservices.amazon.com"
    PAAPI_REGION: str = "us-east-1"
    PAAPI_MARKETPLACE: str = "www.amazon.com"

    # Import behavior
    ITEMS_PER_SUBCATEGORY: int = 10
    PAAPI_REQUEST_DELAY_SECONDS: float = 1.1  # PA-API default rate limit ~1 req/sec

    @property
    def is_production(self) -> bool:
        return self.APP_ENV.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
